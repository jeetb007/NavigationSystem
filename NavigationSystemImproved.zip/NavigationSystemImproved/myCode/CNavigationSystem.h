/*
 * CNavigationSystem.h
 *
 *  Created on: 05-Nov-2017
 *      Author: jb
 */

#ifndef CNAVIGATIONSYSTEM_H_
#define CNAVIGATIONSYSTEM_H_

#include "CRoute.h"
#include "CWpDatabase.h"
#include "CPoiDatabase.h"
#include "CGPSSensor.h"
#include "CPersistenceStorage.h"
#include<fstream>
#include<sstream>
#include <string>

#include "CPoiDatabase.h"
using namespace std;

class CNavigationSystem {
private:
	CGPSSensor m_GPSSensor;
	CRoute m_route;
	CPoiDatabase m_PoiDatabase;
	CWpDatabase m_WpDatabase;
	string m_fileName;
public:
	CNavigationSystem();
	//Run is called from the main function
	void run();
private:
	//these functions are called inside the run method
	//Enter route adds elements to the navigation system.
	//It creates the Databases
	void enterRoute();
	//Printing the route
	void printRoute();
//	void printDistanceCurPosNextPoi();


};


#endif  //CNAVIGATIONSYSTEM_H_

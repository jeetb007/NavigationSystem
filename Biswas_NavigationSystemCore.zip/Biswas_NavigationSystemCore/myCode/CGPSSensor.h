/*
 * CGPSSensor.h
 *
 *  Created on: 03-Nov-2017
 *      Author: jb
 */

#ifndef CGPSSENSOR_H_
#define CGPSSENSOR_H_
#include "Cwaypoint.h"
using namespace std;

class CGPSSensor :public Cwaypoint{
public:
	CGPSSensor();
	Cwaypoint getCurrentPosition();
};

#endif /* CGPSSENSOR_H_ */

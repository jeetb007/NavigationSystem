/*
 * Filehandling.h
 *
 *  Created on: 13.12.2017
 *      Author: stjebisw
 */

#ifndef FILEHANDLING_H_
#define FILEHANDLING_H_
#include "CPersistenceStorage.h"
#include <fstream>

class Filehandling:public CPersistenceStorage
{
public:
	virtual ~Filehandling();
	void setmediaName(std::string name);
	bool writeData(const CWpDatabase& waypointDB, const CPoiDatabase& poiDB);
	bool readData(CWpDatabase& waypointDb, CPoiDatabase& poiDb, MergeMode mode);

private:
	string m_name;
    ofstream WpStorage;
    ofstream PoiStorage;
    ifstream WpRead;
    ifstream PoiRead;
};

#endif /* FILEHANDLING_H_ */

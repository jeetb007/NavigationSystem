/*
 * main.cpp
 *
 *  Created on: 25-Oct-2017
 *      Author: jb
 */


#include "Cwaypoint.h"
#include "CpoiDatabase.h"
#include "CPOI.h"
#include "CRoute.h"
#include "CGPSSensor.h"
#include "CNavigationSystem.h"
#include<iostream>
using namespace std;

int main(){

	Cwaypoint Darmstadt("Darmstadt",49.87,8.65);
	Cwaypoint Amsterdam("Amsterdam",52.37,4.89);
	Cwaypoint Berlin("Berlin",52.5166,13.4);
	Cwaypoint Tokio("Tokio",35.68,139.69);
	Cwaypoint newWaypoint;

	cout<<"=========="<<endl<<"print method"<<endl<<"=========="<<endl;
	Berlin.print(DEGREE);
	Berlin.print(MMSS);

	//testing get functions
	cout<<"Name of the object: "<<Amsterdam.getName()<<endl;
	cout<<"Latitude of the object: "<<Amsterdam.getLatitude()<<endl;
	cout<<"Longitude of the object: "<<Amsterdam.getLongitude()<<endl;

	//gettingAllDataByReference
	string name;
	double latitude,longitude;
	cout<<"before Call by reference"<<endl;
	cout<<"Name = "<<name<<"Latitude = "<<latitude<<"Longitude= "<<longitude<<endl;
	Tokio.getAllDataByReference(name,latitude,longitude);
	cout<<"after call by reference"<<endl;
	cout<<"Name = "<<name<<"Latitude = "<<latitude<<"Longitude= "<<longitude<<endl;
	//Both Local Variables and parameters have same address as passed by reference

	//Calculate Distance
	float distance;
	distance= Amsterdam.calculateDistance(Berlin);
	cout<<"=========="<<endl<<"and a first real method"<<endl<<"=========="<<endl;
	cout<<"Distance between Amsterdam and Berlin: "<<distance<<"Kms"<<endl;
	distance= Tokio.calculateDistance(Berlin);
	cout<<"Distance between Tokio and Berlin: "<<distance<<endl;

	//Implementation of Complete Navigation System
	CNavigationSystem test3;
	test3.run();
}




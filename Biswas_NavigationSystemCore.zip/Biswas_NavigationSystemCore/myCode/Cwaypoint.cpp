/*
 * Cwaypoint.cpp
 *
 *  Created on: 25-Oct-2017
 *      Author: jb
 */

#include "Cwaypoint.h"
#include<iostream>
#include<cmath>
using namespace std;

//the constructor
Cwaypoint::Cwaypoint(string name,double latitude,double longitude) {
	//Calling the set method to check
	set(name,latitude,longitude);
	//showing address of the object
	#ifdef SHOWADDRESS
		cout<<"CWaypoint "<<m_name<<" Created at Location:"<<this<<endl;
		cout<<"name stored at : "<<&m_name<<" Occupying "<<sizeof(m_name)<<" Bytes"<<endl;
		cout<<"Latitude at :"<<&m_latitude<<" Occupying "<<sizeof(m_latitude)<<" Bytes"<<endl;
		cout<<"Longitude at :"<<&m_longitude<<" Occupying "<<sizeof(m_longitude)<<" Bytes"<<endl;
	#endif
}

//Set method which checks validity and also writes correct values to the attributes
void Cwaypoint::set(string name, double latitude, double longitude) {
	//Checking whether parameters are valid or not
	if(latitude > 90.0 || latitude<-90.0||longitude > 180.0 || longitude < -180.0){
		cout<<"Parameters are invalid. Setting co-ordinate(0,0) instead"<<endl;
		m_name = "ImaginaryWP";
		m_latitude=0;
		m_longitude=0;
	}
	else{
		m_name = name;
		m_latitude = latitude;
		m_longitude = longitude;
	}
}

void Cwaypoint::print(int format) {
	switch (format){
	case 1:
		cout<<m_name<<" on Latitude ="<<m_latitude<<", Longitude ="<<m_longitude<<endl;
		break;
	case 2:
		int deg, mm;
		double ss;
		transformLongitude2degmmss(deg,mm,ss);
		cout<<m_name<<" on Latitude "<<deg<<" degrees "<<mm<<" mins "<<ss<<" s and ";
		transformLatitude2degmmss(deg,mm,ss);
		cout<<"Longitude "<<deg<<" degrees "<<mm<<" mins "<<ss<<" s"<<endl;
		break;
	}
}


void Cwaypoint::transformLongitude2degmmss(int& deg, int& mm, double& ss) {
	deg=m_latitude;
	mm=(m_latitude-deg)*60;
	ss=((m_latitude-deg)*60-mm)*60;
}

void Cwaypoint::transformLatitude2degmmss(int& deg, int& mm, double& ss) {
	deg=m_longitude;
	mm=(m_longitude-deg)*60;
	ss=((m_longitude-deg)*60-mm)*60;
}

double Cwaypoint :: calculateDistance ( Cwaypoint &wp)const {

float dist;
//the formula uses Radians so you need to multiply a certain factor to convert degree  to radian
const float degtorad = 0.0175433, RofEarth = 6378.17;

dist = RofEarth * acos ( sin ( m_latitude * degtorad) * sin (wp. m_latitude * degtorad) + cos ( m_latitude * degtorad) * cos (wp. m_latitude * degtorad) * cos (wp. m_longitude * degtorad- m_longitude * degtorad) );

return dist;

}

void Cwaypoint::getAllDataByReference(string& name, double& latitude,double& longitude) {
	name=getName();
	latitude=getLatitude();
	longitude=getLongitude();
}


string Cwaypoint::getName() {
	return m_name;
}

double Cwaypoint::getLatitude() {
	return m_latitude;
}

double Cwaypoint::getLongitude() {
	return m_longitude;
}



/*
 * Cwaypoint.h
 *
 *  Created on: 25-Oct-2017
 *      Author: jb
 */
#define DEGREE 1
#define MMSS 2
//#define SHOWADDRESS
#ifndef CWAYPOINT_H_
#define CWAYPOINT_H_

#include<string>
using namespace std;

class Cwaypoint {
protected:
	string m_name;
	double m_latitude;
	double m_longitude;
public:
	Cwaypoint(string name="",double latitude=0,double longitude=0);
	void set(string name,double latitude,double longitude);
	//to access the methods
	string getName();
	double getLatitude();
	double getLongitude();
	void getAllDataByReference(string& name, double& latitude, double& longitude);
	//calculate distance
	double calculateDistance (Cwaypoint &wp)const;
	//Printing
	void print(int format);
	//transform
private:
	void transformLongitude2degmmss(int &deg,int &mm, double &ss);
	void transformLatitude2degmmss(int &deg,int &mm, double &ss);


};

#endif /* CWAYPOINT_H_ */

/*
 * CpoiDatabase.cpp
 *
 *  Created on: 01-Nov-2017
 *      Author: jb
 */

#include "CpoiDatabase.h"
#include<iostream>

using namespace std;

CpoiDatabase::CpoiDatabase(){
	m_noPoi=0;//Initially the number of elementsshould be zero
}

void CpoiDatabase::addPoi(t_poi type, string name, string description, double latitude, double longitude) {
	//Checking whether the DB is full or not
	if(m_noPoi==9)
		cout<<"Database Full"<<endl;
	else{
		CPOI newpoi(type,name,description,latitude,longitude);
		m_POI[m_noPoi]=newpoi;
		m_noPoi++;
	}
}

CPOI* CpoiDatabase::getPointerToPoi(string name) {
	if(m_noPoi==0)
		cout<<"The Data base is Empty"<<endl;
	//search for the matching string
	else{
		for(int i=0;i<m_noPoi;i++){
			if(m_POI[i].getName()==name)
				return m_POI+i;
		}
	}
	return NULL;
}

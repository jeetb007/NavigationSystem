/*
 * CNavigationSystem.cpp
 *
 *  Created on: 05-Nov-2017
 *      Author: jb
 */
#include "CNavigationSystem.h"
#include "CRoute.h"
#include "CpoiDatabase.h"
#include<iostream>
using namespace std;

void CNavigationSystem::enterRoute() {
	//Adding Waypoints
	Cwaypoint Darmstadt("Darmstadt",49.87,8.65);
	Cwaypoint Amsterdam("Amsterdam",52.37,4.89);
	m_route.addWaypoint(Darmstadt);
	m_route.addWaypoint(Amsterdam);
	//Adding POIs to DB
	m_PoiDatabase.addPoi(RESTAURANTS,"HDA_Mensa","Best Mensa",10,20);
	m_PoiDatabase.addPoi(RESTAURANTS,"TU_Mensa","2nd Best Mensa",11,22);
	m_PoiDatabase.addPoi(GASSTATION,"Aral","Cheap Petrol",13,26);
	m_PoiDatabase.addPoi(RESTAURANTS,"Sitte","Expensive but good",14,28);
	//Connecting the DB to Route
	m_route.connectToPoiDatabase(&m_PoiDatabase);
	//Fetching the POIs from DB
	m_route.addPoi("HDA_Mensa");
	m_route.addPoi("TU_Mensa");
	m_route.addPoi("ARAL");
	m_route.addPoi("Aral");
	m_route.addPoi("Sitte");
}

CNavigationSystem::CNavigationSystem():m_route(10,10) {

}

void CNavigationSystem::printDistanceCurPosNextPoi() {
	CPOI DummyObject;
	Cwaypoint CurrPos;
	CurrPos = m_GPSSensor.getCurrentPosition();
	double dist = m_route.getDistanceNextPoi(CurrPos,DummyObject);

	CurrPos.print(MMSS);
	cout<<"Distance to Next POI: "<<dist<<endl;
	DummyObject.print();
}

void CNavigationSystem::run() {
	enterRoute();
	printRoute();
	printDistanceCurPosNextPoi();

}

void CNavigationSystem::printRoute() {
	m_route.print();
}

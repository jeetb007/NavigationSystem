 /** CRoute.h
 *
 *  Created on: 03-Nov-2017
 *      Author: jb
*/

#ifndef CROUTE_H_
#define CROUTE_H_
#include<string>

#include "CPoiDatabase.h"
#include"Cwaypoint.h"
#include"CPOI.h"
#include"CWpDatabase.h"
#include<list>
using namespace std;

class CRoute {
private:
	//A list to store all the Waypoints and the POIs of the route
	std::list<Cwaypoint* > m_pRoute;
	//Pointers to get the address of the databases
	CPoiDatabase* m_pPoiDatabase;
	CWpDatabase* m_pWpDatabase;

public:
	//Constructor
	CRoute();
	//Copy constructor
	CRoute(CRoute& original);
	//Destructor
	~CRoute();
	//Connecting Existing Databases to the Route
	void connectToPoiDatabase(CPoiDatabase* pPoiDB);
	void connectToWPDatabase(CWpDatabase* pWpDB);
	//Adding elements to the route from the existing Database
	void addWaypoint(string name);
	void addPoi(string namePoi, string afterWp);
	//Operator Overloading
	//adding elements to the Route. either Waypoint or POI or both
	void operator +=(const string& name);
	friend CRoute operator +( CRoute& lhs, CRoute& rhs);
	//double getDistanceNextPoi(Cwaypoint& wp,CPOI& poi);
	//Printing the route
	void print();

};

#endif  /*CROUTE_H_*/

/*
 * CPOI.cpp
 *
 *  Created on: 01-Nov-2017
 *      Author: jb
 */

#include "CPOI.h"
#include<iostream>

using namespace std;

CPOI::CPOI(t_poi type, string name, string description, double latitude,
	double longitude) {
	this->set(type,name,description,latitude,longitude);
}

void CPOI::getAllDataByReference(string& type, string& name, string& description,
		double& latitude, double& longitude) {

		name=m_name;
		description=m_description;
		latitude=m_latitude;
		longitude=m_longitude;
		switch(m_type){
		case 0:
			type="RESTAURANTS";
			break;
		case 1:
			type="SIGHTSEEING";
			break;
		case 2:
			type="GASSTATION";
			break;
		}
}

void CPOI::print() {
	switch(m_type){
	case 0:
		cout<<"Point of Interest-"<<endl;
		cout<<"of type Restaurant"<<" : "<<m_description<<endl;
		cout<<m_name<<" On Latitude = "<<m_latitude<<" and on Longitude = "<<m_longitude<<endl;
		break;
	case 1:
		cout<<"Point of Interest-"<<endl;
		cout<<"of type SIGHTSEEING"<<" : "<<m_description<<endl;
		cout<<m_name<<" On Latitude = "<<m_latitude<<" and on Longitude = "<<m_longitude<<endl;
		break;
	case 2:
		cout<<"Point of Interest-"<<endl;
		cout<<"of type GASSTATION"<<" : "<<m_description<<endl;
		cout<<m_name<<" On Latitude = "<<m_latitude<<" and on Longitude = "<<m_longitude<<endl;
		break;
	}

}

void operator<<(ostream& out, CPOI& m_poi){
	switch(m_poi.m_type){
	case 0:
		out<<"POI "<<m_poi.m_name<<" of type Restaurant"<<" On Latitude = "<<m_poi.m_latitude<<" and on Longitude = "<<m_poi.m_longitude<<endl;
		break;
	case 1:
		out<<"POI "<<m_poi.m_name<<" of type Sight Seeing"<<" On Latitude = "<<m_poi.m_latitude<<" and on Longitude = "<<m_poi.m_longitude<<endl;
		break;
	case 2:
		out<<"POI "<<m_poi.m_name<<" of type Gas Station"<<" On Latitude = "<<m_poi.m_latitude<<" and on Longitude = "<<m_poi.m_longitude<<endl;
		break;
	}

}

void CPOI::set(t_poi type, string name, string description, double latitude,
		double longitude){
	m_type=type;
	m_name=name;
	m_description=description;
	if(latitude > 90.0 || latitude<-90.0||longitude > 180.0 || longitude < -180.0){
		cout<<"Lat/Long Parameters are invalid. Setting co-ordinate(0,0) instead and name Imaginary"<<endl;
		m_name = "ImaginaryWP";
		m_latitude=0;
		m_longitude=0;
	}
	else{
		m_name = name;
		m_latitude = latitude;
		m_longitude = longitude;
	}
}

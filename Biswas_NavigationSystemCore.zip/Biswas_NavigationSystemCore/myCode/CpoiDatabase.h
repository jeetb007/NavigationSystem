/*
 * CpoiDatabase.h
 *
 *  Created on: 01-Nov-2017
 *      Author: jb
 */

#ifndef CPOIDATABASE_H_
#define CPOIDATABASE_H_

#include <string>
#include"CPOI.h"

using namespace std;

class CpoiDatabase {
private:
	CPOI m_POI[10];
	int m_noPoi;
public:
	CpoiDatabase();
	void addPoi(t_poi type,string name, string description,double latitude,double longitude);
	CPOI* getPointerToPoi(string name);

};


#endif /* CPOIDATABASE_H_ */

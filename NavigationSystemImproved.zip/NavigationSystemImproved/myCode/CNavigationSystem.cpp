/*
 * CNavigationSystem.cpp
 *
 *  Created on: 05-Nov-2017
 *      Author: jb
 */
#include "CNavigationSystem.h"
#include "CWpDatabase.h"
#include "CRoute.h"
#include <iostream>
#include "CPoiDatabase.h"
#include<string>

using namespace std;

CNavigationSystem::CNavigationSystem()
{
}

void CNavigationSystem::enterRoute() {
	//Adding Waypoints
	Cwaypoint Darmstadt("Darmstadt",49.87,8.65);
	Cwaypoint Amsterdam("Amsterdam",52.37,4.89);
	Cwaypoint Berlin("Berlin",52.5166,13.4);
	Cwaypoint Tokio("Tokio",35.68,139.69);
	CPOI HDA_Mensa(RESTAURANTS,"HDA_Mensa","Best Mensa",10.01,20.01);
	CPOI TU_Mensa(RESTAURANTS,"TU_Mensa","2nd Best Mensa",11.01,22.01);
	CPOI Aral(GASSTATION,"Aral","Cheap Petrol",13.01,26.01);
	CPOI Sitte(RESTAURANTS,"Sitte","Expensive but good",14.01,28.01);
	CPOI BerlinCC(SIGHTSEEING,"Berlin","City center",52.5166,13.4);
	//Adding WayPoints to DB
	m_WpDatabase.addWaypoint(Darmstadt);
	m_WpDatabase.addWaypoint(Amsterdam);
	m_WpDatabase.addWaypoint(Berlin);
	m_WpDatabase.addWaypoint(Tokio);
	m_WpDatabase.addWaypoint(Tokio);
	//Adding POIs to DB
	m_PoiDatabase.addPoi(HDA_Mensa);
	m_PoiDatabase.addPoi(TU_Mensa);
	m_PoiDatabase.addPoi(Aral);
	m_PoiDatabase.addPoi(Sitte);
	m_PoiDatabase.addPoi(BerlinCC);

	//Connecting the DB to Route
	m_route.connectToPoiDatabase(&m_PoiDatabase);
	m_route.connectToWPDatabase(&m_WpDatabase);
	//Fetching the WPs and POIs from DB and adding them to route
	m_route.addWaypoint("Darmstadt");
	m_route.addWaypoint("Amsterdam");
	m_route+="Tokio";
	m_route.addPoi("HDA_Mensa","Darmstadt");
	m_route.addPoi("TU_Mensa","Darmstadt");
	m_route.addPoi("Aral","Amsterdam");
	m_route+="Berlin";
	m_route.print();
	CRoute altRT;
	CWpDatabase WpDB2;
	CPoiDatabase PoiDB2;
	WpDB2.addWaypoint(Darmstadt);
	PoiDB2.addPoi(Sitte);
	altRT.connectToWPDatabase(&m_WpDatabase);
	altRT.connectToPoiDatabase(&m_PoiDatabase);
//	altRT.connectToWPDatabase(&WpDB2);
//	altRT.connectToPoiDatabase(&PoiDB2);
	altRT+="Darmstadt";
	altRT+="Sitt";
	altRT.addPoi("Sitte","Darmstadt");
	CRoute combo=m_route;
	combo=m_route+altRT;
	combo.print();
}


void CNavigationSystem::run() {
	enterRoute();
	//printRoute();
	//printDistanceCurPosNextPoi();

}

void CNavigationSystem::printRoute() {
	m_route.print();
}

/*
 * CpoiDatabase.cpp
 *
 *  Created on: 01-Nov-2017
 *      Author: jb
 */

#include "CPoiDatabase.h"

#include<iostream>

using namespace std;

CPoiDatabase::CPoiDatabase(){

}

void CPoiDatabase::addPoi(const CPOI& poi) {
	CPOI dummyPOI=poi;
	m_POI[dummyPOI.getName()]=poi;
}

CPOI* CPoiDatabase::getPointerToPoi(string name) {
	if(m_POI.empty())
		cout<<"The Database is empty"<<endl;
	else{
		map<const string, CPOI>::iterator itr;
		itr=m_POI.find(name);
		if(itr != m_POI.end())
			return &(m_POI.find(name)->second);
		else
			cout<<"The POI "<<name<<" doesn't exist in the POI DB"<<endl;
	}
	return NULL;
}

/*
 * Filehandling.cpp
 *
 *  Created on: 13.12.2017
 *      Author: stjebisw
 */

#include <iostream>
#include <sstream>
#include <fstream>
#include <vector>
#include<string>
#include<stdlib.h>
#include<map>
#include "Filehandling.h"
#include "CWpDatabase.h"
#include "CRoute.h"
#include "CPoiDatabase.h"

using namespace std;

void Filehandling::setmediaName(std::string name)
{
	m_name=name;
}

bool Filehandling::writeData(const CWpDatabase& waypointDB,
		const CPoiDatabase& poiDB)
{
		CWpDatabase tempWpDB=waypointDB;
		map<const string, Cwaypoint>::iterator itr;
		string name;
		double lat;
		double lon;
		this->WpStorage.open((m_name+"WriteWayPointDB.txt").c_str());
		if(!WpStorage.is_open())
			return false;
		else{
			for(itr=tempWpDB.m_WP.begin();itr!=tempWpDB.m_WP.end();itr++){
				itr->second.getAllDataByReference(name,lat,lon);
				WpStorage<<name<<";"<<lon<<";"<<lat<<endl;
			}
			WpStorage.close();
		}
		CPoiDatabase tempPoiDB=poiDB;
		map<const string, CPOI>::iterator itrPoi;
		string description;
		string type;
		this->PoiStorage.open((m_name+"WritePoiDB.txt").c_str());
		if(!PoiStorage.is_open())
			return false;
		else{
			for(itrPoi=tempPoiDB.m_POI.begin();(itrPoi)!=tempPoiDB.m_POI.end();itrPoi++){
					itrPoi->second.getAllDataByReference(type,name,description,lat,lon);
					PoiStorage<<type<<";"<<name<<";"<<description<<";"<<lon<<";"<<lat<<endl;
				}
			PoiStorage.close();
		}
		return true;
}

Filehandling::~Filehandling()
{
}

bool Filehandling::readData(CWpDatabase& waypointDb, CPoiDatabase& poiDb,
		MergeMode mode)
{
	std::map<string,Cwaypoint> DummyWPDB;
	std::map<string,Cwaypoint>::iterator itrWPDB;
	std::map<string, CPOI> DummyPoiDB;
	std::map<string,CPOI>::iterator itrPoiDB;
	Cwaypoint DummyWP;
	CPOI DummyPoi;
	string element;
	unsigned int linenumber;
	string name="";
	t_poi type;
	string description;
	double latitude=0,longitude=0;

	this->WpRead.open((m_name+"ReadWayPointDB.txt").c_str());
	if(!WpRead.is_open())
			return false;
	linenumber=0;
	while(!WpRead.eof()){
		linenumber++;
		stringstream stream;
		//Read Name
		getline(WpRead,element,';');
		if(element.empty()){
			cout<<"Error: File:"<<m_name<<"ReadWayPointDB.txt Line-"<<linenumber<<":Ignored: Field missing"<<endl;
			getline(WpRead,element,'\n');
			continue;
		}
		name=element;
		//Read Latitude
		getline(WpRead,element,';');
		if(element.empty()){
			cout<<"Error: File:"<<m_name<<"ReadWayPointDB.txt Line-"<<linenumber<<":Ignored: Field missing"<<endl;
			getline(WpRead,element,'\n');
			continue;
		}
		else if(!((std::istringstream(element) >> latitude /*>> std::ws*/).eof())){
			cout<<"Error: File:"<<m_name<<"ReadWayPointDB.txt Line-"<<linenumber<<":Ignored: Not a valid double "<<endl;
			getline(WpRead,element,'\n');
			continue;
		}
		stream<<element;
		stream>>latitude;
		stream.clear();
		//Read Longitude
		getline(WpRead,element,'\n');
		if(element.empty()){
			cout<<"Error: Line-"<<linenumber<<":Ignored: Field missing"<<endl;
			continue;
		}
		else if(!((std::istringstream(element) >> longitude >> std::ws).eof())){
			cout<<"Error: File:"<<m_name<<"ReadWayPointDB.txt Line-"<<linenumber<<":Ignored: Not a valid double"<<endl;
			getline(WpRead,element,'\n');
			continue;
		}
		stream<<element;
		stream>>longitude;
		stream.clear();

		DummyWP.set(name,latitude,longitude);
		DummyWPDB[name]=DummyWP;
	}WpRead.close();

	PoiRead.open((m_name+"ReadPoiDB.txt").c_str());
	if(!PoiRead.is_open())
		return false;

	linenumber=0;
	while(!PoiRead.eof()){
		linenumber++;
		stringstream stream;
		//Reading type
		getline(PoiRead,element,';');
		if(element.empty()){
			cout<<"Error: File:"<<m_name<<"ReadPoiDB.txt Line-"<<linenumber<<":Ignored: Field missing"<<endl;
			getline(PoiRead,element,'\n');
			continue;
		}
		if(element=="RESTAURANTS")
			type=RESTAURANTS;
		else if(element=="SIGHTSEEING")
			type=SIGHTSEEING;
		else if(element=="GASSTATION")
			type=GASSTATION;
		//Reading name
		getline(PoiRead,element,';');
		if(element.empty()){
			cout<<"Error: File:"<<m_name<<"ReadPoiDB.txt Line-"<<linenumber<<":Ignored: Field missing"<<endl;
			getline(PoiRead,element,'\n');
			continue;
		}
		name=element;
		//Reading description
		getline(PoiRead,element,';');
		if(element.empty()){
			cout<<"Error: File:"<<m_name<<"ReadPoiDB.txt Line-"<<linenumber<<":Ignored: Field missing"<<endl;
			getline(PoiRead,element,'\n');
			continue;
		}
		description=element;
		//Reading Latitude
		getline(PoiRead,element,';');
		if(element.empty()){
			cout<<"Error: File:"<<m_name<<"ReadPoiDB.txt Line-"<<linenumber<<":Ignored: Field missing"<<endl;
			continue;
		}
		else if(!((std::istringstream(element) >> latitude >> std::ws).eof())){
			cout<<"Error: File:"<<m_name<<"ReadPoiDB.txt Line-"<<linenumber<<":Ignored: Not a valid double "<<endl;
			getline(PoiRead,element,'\n');
			continue;
		}
		stream<<element;
		stream>>latitude;
		stream.clear();
		//Reading Longitude
		getline(PoiRead,element,'\n');
		if(element.empty()){
			cout<<"Error: File:"<<m_name<<"ReadPoiDB.txt Line-"<<linenumber<<":Ignored: Field missing"<<endl;
			continue;
		}
		else if(!((std::istringstream(element) >> longitude >> std::ws).eof())){
			cout<<"Error: File:"<<m_name<<"ReadPoiDB.txt Line-"<<linenumber<<":Ignored: Not a valid double "<<endl;
			getline(PoiRead,element,'\n');
			continue;
		}

		stream<<element;
		stream>>longitude;
		stream.clear();
		DummyPoi.set(type,name,description,latitude,longitude);
		DummyPoiDB[name]=DummyPoi;
	}PoiRead.close();
	switch(mode){
	case 0:
		for(itrWPDB=DummyWPDB.begin();itrWPDB!=DummyWPDB.end();itrWPDB++){
			name=itrWPDB->first;
			waypointDb.m_WP[name]=itrWPDB->second;
		}

		for(itrPoiDB=DummyPoiDB.begin();itrPoiDB!=DummyPoiDB.end();itrPoiDB++){
			name=itrPoiDB->first;
			poiDb.m_POI[name]=itrPoiDB->second;
		}
		break;
	case 1:
		waypointDb.m_WP.clear();
		poiDb.m_POI.clear();
		for(itrWPDB=DummyWPDB.begin();itrWPDB!=DummyWPDB.end();itrWPDB++){
			name=itrWPDB->first;
			waypointDb.m_WP[name]=itrWPDB->second;
		}

		for(itrPoiDB=DummyPoiDB.begin();itrPoiDB!=DummyPoiDB.end();itrPoiDB++){
			name=itrPoiDB->first;
			poiDb.m_POI[name]=itrPoiDB->second;
		}
		break;
	}
	return true;
}

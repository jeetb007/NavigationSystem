/*
 * CWpDatabase.cpp
 *
 *  Created on: 24-Nov-2017
 *      Author: jb
 */

#include "CWpDatabase.h"
#include<string>
#include<iostream>
using namespace std;

CWpDatabase::CWpDatabase() {
	// TODO Auto-generated constructor stub

}

void CWpDatabase::addWaypoint(const Cwaypoint& wp) {
	Cwaypoint DummyWP=wp;
	m_WP[DummyWP.getName()]=wp;
}

Cwaypoint* CWpDatabase::getPointerToWaypoint(string name) {
	if(m_WP.empty())
			cout<<"The WP Database is empty"<<endl;
		else{
			map<const string, Cwaypoint>::iterator itr=m_WP.begin();
			itr=m_WP.find(name);
			if(itr != m_WP.end())
				return &(m_WP.find(name)->second);
			else
				cout<<"The WP "<<name<<" Doesn't exist in the WP DB"<<endl;
		}
	return NULL;
}


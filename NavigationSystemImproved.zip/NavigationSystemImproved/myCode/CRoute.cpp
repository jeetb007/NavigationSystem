
 /** CRoute.cpp
 *
 *  Created on: 03-Nov-2017
 *      Author: jb
*/

#include "CRoute.h"
#include<iostream>
using namespace std;

CRoute::CRoute() {
	m_pPoiDatabase=NULL;
	m_pWpDatabase=NULL;
	m_pRoute.clear();
}
//Destructor to free the dynamic arrays
CRoute::~CRoute() {
}


CRoute::CRoute(CRoute& original){
	this->m_pRoute.clear();
	this->m_pPoiDatabase=original.m_pPoiDatabase;
	this->m_pWpDatabase=original.m_pWpDatabase;
	//std::list<Cwaypoint*>::iterator itr = m_pRoute.begin();
	//std::list<>
	std::list<Cwaypoint*>::iterator itroriginal ;
	for(itroriginal =original.m_pRoute.begin();(itroriginal)!=(original.m_pRoute.end());itroriginal++){
		this->m_pRoute.push_back(*itroriginal);
	}
}


//Connecting the Databases
void CRoute::connectToPoiDatabase(CPoiDatabase* pPoiDB) {
	m_pPoiDatabase=pPoiDB;
}

void CRoute::connectToWPDatabase(CWpDatabase* pWpDB) {
	m_pWpDatabase=pWpDB;
}
//Adding Waypoints one after one
void CRoute::addWaypoint(string name) {
	Cwaypoint* WP;
	WP=m_pWpDatabase->getPointerToWaypoint(name);
	if(NULL!=WP)
		m_pRoute.push_back(WP);
}

//Searching the WP and adding the POIs after them.
void CRoute::addPoi(string namePoi, string afterWp) {
	std::list<Cwaypoint*>::iterator it;
	for (it=m_pRoute.begin(); it!=m_pRoute.end(); it++){
		if(afterWp==(*(it))->getName()){
			CPOI* Poi;
			Poi=m_pPoiDatabase->getPointerToPoi(namePoi);
			if(NULL!=Poi){
				m_pRoute.insert(++it,Poi);--it;
				break;
			}
			else
				return;
		}
	}
	if(it==m_pRoute.end())
		cout<<"POI - "<<namePoi<< " couldn't be added as there are no waypoints named "<<afterWp<<endl;

}

void CRoute::operator +=(const string& name) {
	if(NULL!=(m_pWpDatabase->getPointerToWaypoint(name))){
		this->addWaypoint(name);
		if(NULL!=(m_pPoiDatabase->getPointerToPoi(name))){
			CPOI* Poi;
			Poi=(m_pPoiDatabase->getPointerToPoi(name));
			m_pRoute.push_back(Poi);
		}
	}
	else if(NULL!=(m_pPoiDatabase->getPointerToPoi(name))){
		CPOI* Poi;
		Poi=(m_pPoiDatabase->getPointerToPoi(name));
		m_pRoute.push_back(Poi);
	}
}

CRoute operator +( CRoute& lhs, CRoute& rhs){
	CRoute NewRoute;
	if(lhs.m_pPoiDatabase==rhs.m_pPoiDatabase && lhs.m_pWpDatabase==rhs.m_pWpDatabase){

		NewRoute=lhs;
		std::list<Cwaypoint*>::iterator itr;
		for(itr=rhs.m_pRoute.begin(); itr!=rhs.m_pRoute.end(); itr++){
				NewRoute.m_pRoute.push_back(*itr);
				return NewRoute;
		}

	}
	return NewRoute;
}

void CRoute::print() {
	if(!m_pRoute.empty()){
		cout<<"=====Charting our course======="<<endl;
		for (std::list<Cwaypoint*>::iterator it=m_pRoute.begin(); it!=m_pRoute.end(); it++){
			if(NULL!=dynamic_cast<CPOI* >(*it)){
				CPOI* temp;
				temp=dynamic_cast<CPOI* >(*it);
				cout<<(*temp);
			}
			else
				cout<<(**it);
		}
		cout<<"=====End of Course======"<<endl;
	}
	else
		cout<<"The Route is empty"<<endl;
}


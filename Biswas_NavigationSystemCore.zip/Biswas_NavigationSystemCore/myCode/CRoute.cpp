
 /** CRoute.cpp
 *
 *  Created on: 03-Nov-2017
 *      Author: jb
*/

#include "CRoute.h"
#include<iostream>
using namespace std;

CRoute::CRoute(unsigned int maxWp, unsigned int maxPoi) {
	m_nextPoi=0;
	m_nextWp=0;

	if (maxPoi >10){
		cout<<"Sorry:POIs cannot be more than 10. Hence setting it to 10."<<endl;
		m_maxPoi=10;
	}
	else
		m_maxPoi=maxPoi;

	m_maxWp=maxWp;

//Assigning memory
	m_pWaypoint=new Cwaypoint[m_maxWp];
	m_pPoiDatabase=NULL;
	m_pPoi=new CPOI*[m_maxPoi];

}

CRoute::CRoute(const CRoute& origin) {
	m_nextPoi=origin.m_nextPoi;
	m_nextWp=origin.m_nextWp;

	m_maxPoi=origin.m_maxPoi;
	m_maxWp=origin.m_maxWp;
	//Deep Copy
	m_pWaypoint = new Cwaypoint[m_maxWp];
	for (unsigned int i = 0; i<m_maxWp; i++)
		m_pWaypoint[i] = origin.m_pWaypoint[i];

	m_pPoi = new CPOI*[m_maxPoi];

	m_pPoiDatabase = NULL;
}

double CRoute::getDistanceNextPoi(Cwaypoint& wp, CPOI& poi){
	poi = *m_pPoi[0];

	double distancetoNearestPoi = m_pPoi[0]->calculateDistance(wp);
	for (unsigned int i = 0; i < m_nextPoi; i++) {
		if (m_pPoi[i]->calculateDistance(wp) < distancetoNearestPoi){
			distancetoNearestPoi = m_pPoi[i]->calculateDistance(wp);
			poi = *m_pPoi[i];
		}

	}
	return distancetoNearestPoi;
}

//Adding Waypoint to the route
void CRoute::addWaypoint(const Cwaypoint& wp) {
	//checking whether memory is allocated or not
	if(NULL==m_pWaypoint){
		cout<<"Sorry!:Cannot add Waypoint! No memory allocated"<<endl;
	}
	//checking whether the route is full or not
	else{
		if(m_maxWp==m_nextWp)
			cout<<"Sorry!:Cannot add WayPoint! Max Waypoint Reached"<<endl;
	//if not add the Waypoint to the route and increment the counter
		else{
			m_pWaypoint[m_nextWp]=wp;
			m_nextWp++;
		}
	}
}

void CRoute::connectToPoiDatabase(CpoiDatabase* pPoiDB) {
	m_pPoiDatabase=pPoiDB;
}

void CRoute::print() {
	cout<<"=====Charting our course======="<<endl;
	cout<<"Our Route has "<<m_nextWp<<" Waypoints and "<<m_nextPoi<<" point of Interests"<<endl;
	//Printing all the WayPoints
	for(unsigned int i=0;i<m_nextWp;i++)
		(m_pWaypoint+i)->print(1);
	//Printing all the POIs
	for(unsigned int i=0;i<m_nextPoi;i++)
		m_pPoi[i]->print();
}


//Add POI to the Route from the existing DB
void CRoute::addPoi(string namePoi) {

		//Checking whether DB is full
		if(m_maxPoi==m_nextPoi)
			cout<<"Sorry! Cannot add POI. Max POI reached"<<endl;
		//Checking whether the POI exists in the DB or not
		else{
			if(m_pPoiDatabase->getPointerToPoi(namePoi)){
				m_pPoi[m_nextPoi]=m_pPoiDatabase->getPointerToPoi(namePoi);
				m_nextPoi++;
			}
			else
				cout<<"ERROR: Could not find "<<namePoi<<" in the database"<<endl;
		}

}

//Destructor to free the dynamic arrays
CRoute::~CRoute() {
	delete []m_pWaypoint;
	delete []m_pPoi;
}



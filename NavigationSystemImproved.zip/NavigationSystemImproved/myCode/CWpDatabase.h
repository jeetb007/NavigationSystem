/*
 * CWpDatabase.h
 *
 *  Created on: 24-Nov-2017
 *      Author: jb
 */

#ifndef MYCODE_CWPDATABASE_H_
#define MYCODE_CWPDATABASE_H_

#include<string>
#include<map>
#include"Cwaypoint.h"
using namespace std;
class CWpDatabase {
private:
	//Using map as a container for the array
	std::map<const string, Cwaypoint> m_WP;

public:
	CWpDatabase();
	//adding Waypoints to the DB
	void addWaypoint(const Cwaypoint& wp);
	//Searching a particular Waypoint by it's name
	Cwaypoint* getPointerToWaypoint(string name);
	//To make sure that Filehandling is able to access the private members of for read write operation
	friend class Filehandling;
};

#endif /* MYCODE_CWPDATABASE_H_ */

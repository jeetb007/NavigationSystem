/*
 * CNavigationSystem.h
 *
 *  Created on: 05-Nov-2017
 *      Author: jb
 */

#ifndef CNAVIGATIONSYSTEM_H_
#define CNAVIGATIONSYSTEM_H_

#include "CRoute.h"
#include "CpoiDatabase.h"
#include "CGPSSensor.h"

#include <string>
using namespace std;

class CNavigationSystem : public CRoute{
private:
	CGPSSensor m_GPSSensor;
	CRoute m_route;
	CpoiDatabase m_PoiDatabase;
	void enterRoute();
	void printRoute();
	void printDistanceCurPosNextPoi();
public:
	CNavigationSystem();
	void run();


};

#endif  //CNAVIGATIONSYSTEM_H_

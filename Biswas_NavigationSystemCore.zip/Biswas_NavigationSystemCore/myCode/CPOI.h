/*
 * CPOI.h
 *
 *  Created on: 01-Nov-2017
 *      Author: jb
 */

#ifndef CPOI_H_
#define CPOI_H_

#include <string>
#include "Cwaypoint.h"
using namespace std;
enum t_poi{RESTAURANTS,SIGHTSEEING, GASSTATION};
class CPOI:public Cwaypoint {
private:
	t_poi m_type;
	string m_description;
public:
	void print();
	CPOI(t_poi type=RESTAURANTS, string name ="Empty",string description ="Empty",double latitiude=0,double longitude=0);
	void getAllDataByReference(t_poi& type, string& name,string& description, double& latitude, double& longitude);

};

#endif /* CPOI_H_ */

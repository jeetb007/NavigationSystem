 /** CRoute.h
 *
 *  Created on: 03-Nov-2017
 *      Author: jb
*/

#ifndef CROUTE_H_
#define CROUTE_H_
#include<string>
#include"Cwaypoint.h"
#include"CPOI.h"
#include"CpoiDatabase.h"

using namespace std;

class CRoute :public CPOI{
private:
	Cwaypoint* m_pWaypoint;
	unsigned int m_maxWp;
	unsigned int m_nextWp;
	CPOI** m_pPoi;
	unsigned int m_maxPoi;
	unsigned int m_nextPoi;
	CpoiDatabase* m_pPoiDatabase;

public:
	CRoute(unsigned int m_maxWp=10, unsigned int m_maxPoi=10);
	CRoute(const CRoute& origin);
	void connectToPoiDatabase(CpoiDatabase* pPoiDB);
	void addWaypoint(const Cwaypoint& wp);
	void addPoi(string namePoi);
	double getDistanceNextPoi(Cwaypoint& wp,CPOI& poi);
	void print();
	~CRoute();
};

#endif  /*CROUTE_H_*/

/*
 * CGPSSensor.cpp
 *
 *  Created on: 03-Nov-2017
 *      Author: jb
 */

#include "CGPSSensor.h"
#include<iostream>
using namespace std;

CGPSSensor::CGPSSensor() {

}

Cwaypoint CGPSSensor::getCurrentPosition() {
	string name="Current Pos";
	double lat,lon;
	Cwaypoint CurrentPos;

	cout<<"Lat: ";
	cin>>lat;
	cout<<"Lon: ";
	cin>>lon;
	CurrentPos.set(name, lat, lon);
	return CurrentPos;
}

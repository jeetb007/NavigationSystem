/*
 * main.cpp
 *
 *  Created on: 25-Oct-2017
 *      Author: jb
 */


#include "Cwaypoint.h"
#include "CPOI.h"
#include "CRoute.h"
#include "CGPSSensor.h"
#include "CNavigationSystem.h"
#include<iostream>
#include<fstream>
#include<sstream>
#include "CPoiDatabase.h"
#include "CWpDatabase.h"
#include "Filehandling.h"
using namespace std;

int main(){

	CNavigationSystem test3;
	test3.run();

	CPoiDatabase PoiDB2;
	CWpDatabase WpDB2;
	Filehandling DBHandling;
	DBHandling.setmediaName("CSV");
	bool j=DBHandling.readData(WpDB2,PoiDB2,REPLACE);
	if(j==false)
		cout<<"Unable to read data from DBs"<<endl;
	bool k=DBHandling.writeData(WpDB2,PoiDB2);
	if(k==false)
		cerr<<"Unable to write Data in CSV file"<<endl;
}

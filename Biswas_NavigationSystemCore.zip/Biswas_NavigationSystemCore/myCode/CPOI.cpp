/*
 * CPOI.cpp
 *
 *  Created on: 01-Nov-2017
 *      Author: jb
 */

#include "CPOI.h"
#include<iostream>

using namespace std;

CPOI::CPOI(t_poi type, string name, string description, double latitude,
	double longitude) {
	m_type=type;
	m_name=name;
	m_description=description;
	m_latitude=latitude;
	m_longitude=longitude;
}

void CPOI::getAllDataByReference(t_poi& type, string& name, string& description,
		double& latitude, double& longitude) {
		type=m_type;
		name=m_name;
		description=m_description;
		latitude=m_latitude;
		longitude=m_longitude;
}

void CPOI::print() {
	switch(m_type){
	case 0:
		cout<<"Point of Interest-"<<endl;
		cout<<"of type Restaurant"<<" : "<<m_description<<endl;
		cout<<m_name<<" On Latitude = "<<m_latitude<<" and on Longitude = "<<m_longitude<<endl;
		break;
	case 1:
		cout<<"Point of Interest-"<<endl;
		cout<<"of type SIGHTSEEING"<<" : "<<m_description<<endl;
		cout<<m_name<<" On Latitude = "<<m_latitude<<" and on Longitude = "<<m_longitude<<endl;
		break;
	case 2:
		cout<<"Point of Interest-"<<endl;
		cout<<"of type GASSTATION"<<" : "<<m_description<<endl;
		cout<<m_name<<" On Latitude = "<<m_latitude<<" and on Longitude = "<<m_longitude<<endl;
		break;
	}

}

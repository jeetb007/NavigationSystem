/*
 * CPersistenceStorage.h
 *
 *  Created on: 04.12.2017
 *      Author: stjebisw
 */

#ifndef CPERSISTENCESTORAGE_H_
#define CPERSISTENCESTORAGE_H_
#include <string>
#include "CWpDatabase.h"
#include "CPoiDatabase.h"
enum MergeMode{ MERGE, REPLACE};
class CPersistenceStorage
{
public:

	//For giving the path where Read write operations take place
	virtual void setmediaName(std::string name) = 0;
	//For writing the contents of an existing DB into a file
	virtual bool writeData(const CWpDatabase& waypointDb, const CPoiDatabase& poiDb) = 0;
	//For Reading the contents of a file and add the elements to the existing DB
	virtual bool readData(CWpDatabase& waypointDb, CPoiDatabase& poiDb,MergeMode mode) = 0;

};



#endif /* CPERSISTENCESTORAGE_H_ */

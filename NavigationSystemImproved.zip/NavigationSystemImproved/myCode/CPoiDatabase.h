/*
 * CPoiDatabase.h
 *
 *  Created on: 01-Nov-2017
 *      Author: jb
 */

#ifndef CPOIDATABASE_H_
#define CPOIDATABASE_H_

#include <string>
#include"CPOI.h"
#include<map>

using namespace std;

class CPoiDatabase {
private:
	std:: map<const string, CPOI> m_POI;
public:
	CPoiDatabase();
	//addign POI to the DB
	void addPoi(const CPOI& poi);
	//Searching a particular element in the database by its's name
	CPOI* getPointerToPoi(string name);
	//To make sure that Filehandling is able to access the private members of the class for read write operation
	friend class Filehandling;
};


#endif /* CPOIDATABASE_H_ */
